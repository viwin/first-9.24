//
//  AppDelegate.h
//  UIApp16_1
//
//  Created by 杨 国俊 on 15/9/22.
//  Copyright (c) 2015年 sdzy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

